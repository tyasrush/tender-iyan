<?php
echo "host pada pc ini : " . date("Y-m-d", strtotime("31/07/2016"));
 ?>
