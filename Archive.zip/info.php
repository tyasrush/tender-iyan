<?php
echo "host pada pc ini : " . $_SERVER['REMOTE_ADDR'];
 ?>
